
import { useEffect, useState } from 'react'
import { useMuatData } from '@/hooks/useMuatData'
import {
  ambilDaftarChecklist,
  buatChecklist,
  hapusChecklist,
  tambahItem,
  ubahItem,
  hapusItem,
} from '@/api/checklist'

function ChecklistPage() {
  const { data: daftarChecklist, memuat } = useMuatData(
    () => ambilDaftarChecklist(),
    []
  )

  const [checklists, setChecklists] = useState([])

  useEffect(() => {
    setChecklists(daftarChecklist || [])
  }, [daftarChecklist])

  // Memuat ulang daftar checklist
  async function muatUlang() {
    const hasil = await ambilDaftarChecklist()
    setChecklists(hasil?.data ?? hasil ?? [])
  }

  // Membuat checklist baru
  async function handleBuatChecklist() {
    const judul = window.prompt('Masukkan nama pembelajaran:')

    if (!judul?.trim()) return

    try {
      await buatChecklist({ judul: judul.trim() })
      await muatUlang()
    } catch (error) {
      alert('Gagal membuat checklist.')
    }
  }

  // Menambahkan materi
  async function handleTambahItem(checklistId) {
    const isi = window.prompt('Masukkan nama materi:')

    if (!isi?.trim()) return

    try {
      await tambahItem(checklistId, isi.trim())
      await muatUlang()
    } catch (error) {
      alert('Gagal menambahkan materi.')
    }
  }

  // Mengubah status checkbox
  async function handleToggleItem(item) {
    try {
      await ubahItem(item.id, { selesai: !item.selesai })
      await muatUlang()
    } catch (error) {
      alert('Gagal mengubah status materi.')
    }
  }

  // Menghapus materi
  async function handleHapusItem(itemId) {
    if (!window.confirm('Hapus materi ini?')) return

    try {
      await hapusItem(itemId)
      await muatUlang()
    } catch (error) {
      alert('Gagal menghapus materi.')
    }
  }

  // Menghapus checklist
  async function handleHapusChecklist(id) {
    if (!window.confirm('Hapus pembelajaran ini beserta seluruh materinya?')) return

    try {
      await hapusChecklist(id)
      await muatUlang()
    } catch (error) {
      alert('Gagal menghapus checklist.')
    }
  }

  return (
    <main className="checklist-page">
      {/* Header */}
      <header className="checklist-header">
        <div>
          <h1>Checklist Belajar</h1>
          <p>Membantu mempermudah kamu dalam belajar</p>
        </div>

        <button
          type="button"
          className="checklist-add-button"
          onClick={handleBuatChecklist}
        >
          Tambah Pembelajaran
        </button>
      </header>

      {/* Konten Checklist */}
      {memuat ? (
        <p className="checklist-message">Memuat data...</p>
      ) : checklists.length === 0 ? (
        <div className="checklist-empty">
          <h3>Belum ada pembelajaran</h3>
          <p>Klik tombol Tambah Pembelajaran untuk memulai.</p>
        </div>
      ) : (
        <div className="checklist-grid">
          {checklists.map((checklist) => {
            const items = checklist.items || []
            const total = items.length
            const selesai = items.filter((item) => item.selesai).length

            const progress =
              total > 0 ? Math.round((selesai / total) * 100) : 0

            return (
              <section className="checklist-card" key={checklist.id}>
                {/* Judul */}
                <div className="checklist-card-title">
                  <h3>{checklist.judul}</h3>

                  <button
                    type="button"
                    className="checklist-delete-card"
                    title="Hapus pembelajaran"
                    onClick={() => handleHapusChecklist(checklist.id)}
                  >
                    ×
                  </button>
                </div>

                {/* Isi kartu */}
                <div className="checklist-card-content">
                  <div className="checklist-item-list">
                    {items.map((item) => (
                      <div className="checklist-item" key={item.id}>
                        <input
                          type="checkbox"
                          id={`item-${item.id}`}
                          checked={Boolean(item.selesai)}
                          onChange={() => handleToggleItem(item)}
                        />

                        <label htmlFor={`item-${item.id}`}>
                          {item.isi}
                        </label>

                        <button
                          type="button"
                          className="checklist-delete-item"
                          title="Hapus materi"
                          onClick={() => handleHapusItem(item.id)}
                        >
                          ×
                        </button>
                      </div>
                    ))}

                    <button
                      type="button"
                      className="checklist-add-item"
                      onClick={() => handleTambahItem(checklist.id)}
                    >
                      + Tambah materi
                    </button>
                  </div>

                  {/* Progress lingkaran */}
                  <div className="checklist-progress-area">
                    <div
                      className="checklist-progress-circle"
                      style={{
                        '--progress': `${progress}%`,
                      }}
                    >
                      <span>{progress}%</span>
                    </div>
                  </div>
                </div>
              </section>
            )
          })}
        </div>
      )}
    </main>
  )
}

export default ChecklistPage
