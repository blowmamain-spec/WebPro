import { fileURLToPath, URL } from 'node:url'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      // '@/api/tugas' artinya 'src/api/tugas', dari file mana pun
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
})
